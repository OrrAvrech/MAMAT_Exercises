#ifndef _POLY_F
#define _POLY_F
#include <stdio.h>
#include <stdlib.h>
#include <string>

using namespace std;

class polynom;
std::ostream& operator<<(std::ostream&, const polynom&);
int InnerProduct(const polynom&, const polynom&);
int SqNorm(const polynom&);
int SqDistance(const polynom&, const polynom&);

class polynom  {
public:
	polynom(int n=0, int* coefs=NULL);
	~polynom();
	polynom& operator=(const polynom& other);
	friend polynom operator+(const polynom&, const polynom&);
	friend polynom operator-(const polynom&, const polynom&);
	friend polynom operator*(const polynom&, const polynom&);
	friend polynom operator*(int scalar, const polynom& p2);
	friend std::ostream& operator<<(std::ostream&, const polynom&);

	friend int InnerProduct(const polynom&, const polynom&);
	friend int SqNorm(const polynom&);
	friend int SqDistance(const polynom&, const polynom&);
	int GetOrder() const;
	int* GetCoefs();
protected:
	int n_;
	int* coefs_;
};

#endif
 
