#ifndef _COMPLEX_H
#define _COMPLEX_H

#include <iostream>

class complex{
public:
	complex(int re = 0, int im = 0) :re_(re), im_(im){};
	//complex() : re_(0), im_(0) {};
	//complex(int re) : re_(re), im_(0) {};
	//complex(int re, int im);
	//operator int() const { return re_; }
	~complex() {};
	int GetReal() const;
	int GetIM() const;
	complex& operator=(const complex& z);
	friend complex operator+(const complex&, const complex&);
	friend complex operator-(const complex&, const complex&);
	friend complex operator*(const complex&, const complex&);
	friend std::ostream& operator<<(std::ostream&, const complex&);
	complex conj() const;
protected: 
	int re_;
	int im_;
};


//*********************************************************************************************************
//* function name:	InnerProduct
//* Description  :	Return the inner product between two complex numbers. Meaning, z1*conj(z2)
//* Parameters   :	z1 - the first complex number
//*					z2 - the second complex number
//* Return Value :	c - the result (complex number)
//*********************************************************************************************************
inline complex InnerProduct(const complex& z1, const complex& z2) {
	return z1 * z2.conj();
}

//*********************************************************************************************************
//* function name:	SqNorm
//* Description  :	Return the square norm of the complex number. Meaning, for ||z||^2
//* Parameters   :	c1 - the first complex number
//*					c2 - the second complex number
//* Return Value :	c - the result (complex number)
//*********************************************************************************************************
inline complex SqNorm(const complex& z) {
	return InnerProduct(z, z);
}

//*********************************************************************************************************
//* function name:	SqDistance
//* Description  :	Return the square distance between two complex numbers. Meaning, ||z1-z2||
//* Parameters   :	z1 - the first complex number
//*					z2 - the second complex number
//* Return Value :	c - the result (complex number)
//*********************************************************************************************************
inline complex SqDistance(const complex& z1, const complex& z2) {
	complex c = z1 - z2;
	return SqNorm(c);
}

#endif


