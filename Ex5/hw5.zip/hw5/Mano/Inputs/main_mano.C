#include <iostream>
#include "polynom.h"
#include "complex.h" 
#include "TempVec.h"

using namespace std;

//typedef TempVec<int, 3> Integer3;

int main1() {

	int size = 3;
	TempVec<int, 3> v1, v2, v3;

	v1[0] = 1;
	v1[1] = 2;
	v1[2] = 3;
	v2[0] = 1;
	v2[1] = 2;
	v2[2] = 3;


	cout << v1 << endl;
	cout << v2 << endl;

	cout << v1 + v2 + v2 +v2 << endl;
	return 0;
}

int main4() {
	int coefs1[3] = { 0, 9, 0 };
	int coefs2[2] = { 0, 1 };
	polynom p1(2, coefs1);
	polynom p2(1, coefs2);
	cout << p1 << "\n";
	cout << p2 << "\n";
	cout << p1*p2 << "\n";
	cout << InnerProduct(p1, p2) << "\n";
	return 0;
}

int main() {

	cout << "---------------------Poly Check ---------------------\n";
	cout << "================>Print\n";
	int coefs1[3] = { 1,-1,2 };
	int coefs2[3] = { 0,0,0 };
	int coefs3[3] = { 1,0,0 };
	int coefs4[3] = { 0,1,0 };
	int coefs5[3] = { 0,0,1};
	int coefs6[3] = { -1,0,0 };
	int coefs7[3] = { 0,-1,0 };
	int coefs8[3] = { 0,0,-1 };
	int coefs9[3] = { 100,-100,-1 };
	int coefs10[3] = { -1,-1,-1 };
	int coefs11[3] = { 200,-100,-5 };
	int coefs12[10] = { 0,0,-1 ,5,6,0,8,7,-30,5 };
	int coefs13[10] = { -1,0,-1 ,1,1,0,0,-57,30,9 };
	int coefs14[10] = { -1,0,-1 ,1,1,0,0,-57,30,0 };
	int coefs15[10] = { 0,0,-1 ,1,1,0,0,-57,30,9 };
	int coefs16[3] = { 1, 0, 2 };
	int coefs17[2] = { 0, 1 };
	polynom p1(2, coefs1);
	polynom p2(2, coefs2);
	polynom p3(2, coefs3);
	polynom p4(2, coefs4);
	polynom p5(2, coefs5);
	polynom p6(2, coefs6);
	polynom p7(2, coefs7);
	polynom p8(2, coefs8);
	polynom p9(2, coefs9);
	polynom p10(2, coefs10);
	polynom p11(2, coefs11);
	polynom p12(9, coefs12);
	polynom p13(9, coefs13);
	polynom p14(9, coefs14);
	polynom p15(9, coefs15);
	polynom p16(2, coefs16);
	polynom p17(1, coefs17);

	cout << p1 << "\n"<< p2 << "\n" << p3 << "\n" << p4 << "\n" << p5 << "\n" << p6 << "\n" << p7 << "\n" << p8 << "\n" << p9 << "\n" << p10 << "\n" << p11 << "\n" << p12 << "\n" << p13 << "\n" << p14 << "\n" << p15<<"\n";
	
	cout << "================>Get Coefs\n"<<"\n";
	int* tmp =  p1.GetCoefs(); 
	for (int i = 0; i < p1.GetOrder()+1; ++i)
		cout << " " << tmp[i] << " ";
	cout << "\n"<<"\n";
	delete[] tmp; 
	tmp = p13.GetCoefs();
	for (int i = 0; i < p13.GetOrder() + 1; ++i)
		cout << " " << tmp[i] << " ";
	delete[] tmp; 
	cout << "\n";

	cout << "================>Op +\n";
	polynom p100 = p1 + p2;
	cout << p100; 
	p100 = p13 + p12;
	cout << p100<<"\n"; 
	cout << "p1 + p2 :\n" << p1 + p2<<"\n";
	cout << "p1 + p3 :\n" << p1 + p3<<"\n";
	cout << "p2 + p3 :\n" << p2 + p3<<"\n";
	cout << "p2 + p4 :\n" << p2 + p4<<"\n";
	cout << "p13 + p12 :\n" << p13 + p12<<"\n";
	cout << "p1 + p12 :\n" << p1 + p12<<"\n";
	cout << "p2 + p12 :\n" << p2 + p12<<"\n";
	cout << "p3 + p12 :\n" << p3 + p12<<"\n";
	cout << "p10 + p10 :\n" << p10 + p10<<"\n";
	cout << "p10 + p13 :\n" << p10 + p13<<"\n";
	cout << "p10 + p13 +p11 :\n" << p10 + p13 +p11<<"\n";
	
	cout << "================>Op -\n"<<"\n";
	cout << "p1 - p2 :\n" << p1 - p2<<"\n";
	cout << "p2 - p1 :\n" << p2 - p1<<"\n";
	cout << "p1 - p3 :\n" << p1 - p3<<"\n";
	cout << "p3 - p1 :\n" << p3 - p1<<"\n";
	cout << "p2 - p3 :\n" << p2 - p3<<"\n";
	cout << "p3 - p2 :\n" << p3 - p2<<"\n";
	cout << "p2 - p4 :\n" << p2 - p4<<"\n";
	cout << "p4 - p2 :\n" << p4 - p2<<"\n";
	cout << "p13 - p12 :\n" << p13 - p12<<"\n";
	cout << "p12 - p13 :\n" << p12 - p13<<"\n";
	cout << "p1 - p12 :\n" << p1 - p12<<"\n";
	cout << "p12 - p1 :\n" << p12 - p1<<"\n";
	cout << "p2 - p12 :\n" << p2 - p12<<"\n";
	cout << "p12 - p2 :\n" << p2 - p12<<"\n";
	cout << "p3 - p12 :\n" << p3 - p12<<"\n";
	cout << "p12 - p3 :\n" << p3 - p12<<"\n";
	cout << "p10 - p10 :\n" << p10 - p10<<"\n";
	cout << "p10 - p8 :\n" << p10 - p8<<"\n";
	cout << "p13 - p15 :\n" << p13 - p15<<"\n";
	cout << "p13 - p14 :\n" << p13 - p14<<"\n";
	tmp = (p13 - p15).GetCoefs();
	for (int i = 0; i < (p13 - p15).GetOrder() + 1; ++i)
		cout << " " << tmp[i] << " ";
	delete[] tmp;
	cout << "\n"<<"\n";
	cout << "The order of p10-p10\n" << (p10 - p10).GetOrder() << "\n";
	cout << "The order of p10-p8\n" << (p10 - p8).GetOrder() << "\n";
	cout << "The order of p13-p15\n" << (p13 - p15).GetOrder() << "\n";
	cout << "The order of p13-p14\n" << (p13 - p14).GetOrder() << "\n";
	cout << "p10 - p13 :\n" << p10 - p13<<"\n";
	cout << "p13 - p10 :\n" << p13 - p10<<"\n";
	cout << "p13 - p10 -p11:\n" << p13 - p10 -p11<<"\n";
	
	cout << "================>Op *\n"<<"\n";
	cout << "p1 * p2 :\n" << p1 * p2<<"\n";
	cout << "p2 * p1 :\n" << p2 * p1<<"\n";
	cout << "p1 * p3 :\n" << p1 * p3<<"\n";
	cout << "p3 * p1 :\n" << p3 * p1<<"\n";
	cout << "p3 * p4 :\n" << p3 * p4<<"\n";
	cout << "p4 * p5 :\n" << p4 * p5<<"\n";
	cout << "p4 * p6 :\n" << p4 * p6<<"\n";
	cout << "p4 * p7 :\n" << p4 * p7<<"\n";
	cout << "p4 * p8 :\n" << p4 * p8<<"\n";
	cout << "p4 * p4 :\n" << p4 * p4<<"\n";
	cout << "p4 * p5 :\n" << p4 * p5<<"\n";
	cout << "p4 * p6 :\n" << p4 * p6<<"\n";
	cout << "p13 * p12 :\n" << p13 * p12<<"\n";
	cout << "p12 * p13 *p11 :\n" << p12 * p13 *p11<<"\n";
	cout << "p1 * p12 :\n" << p1 * p12<<"\n";
	cout << "p12 * p1 :\n" << p12 * p1<<"\n";
	cout << "p2 * p12 :\n" << p2 * p12<<"\n";
	cout << "p12 * p2 :\n" << p2 * p12<<"\n";
	cout << "p3 * p12 :\n" << p3 * p12<<"\n";
	cout << "p12 * p3 :\n" << p3 * p12<<"\n";
	cout << "p4 * p12 :\n" << p4 * p12<<"\n";
	cout << "p10 * p10 :\n" << p10 * p10<<"\n";
	cout << "p10 * p13 :\n" << p10 * p13<<"\n";
	cout << "p13 * p10 :\n" << p13 * p10<<"\n";
	cout << "p13 * p2 :\n" << p13 * p2<<"\n";

	cout << "================>Inner Product *\n"<<"\n";
	cout << "<p1,p2>\n" << InnerProduct(p1,p2)<<"\n";
	cout << "\n<p3,p4>\n" << InnerProduct(p3, p4)<<"\n";
	cout << "\n<p4,p5>\n" << InnerProduct(p4, p5)<<"\n";
	cout << "\n<p13,p12>\n" << InnerProduct(p13, p12) << "\n";
	cout << "Idan B. is the man\n";
	cout << "\n<p16,p17>\n" << InnerProduct(p16, p17) << "\n" << "\n";
	cout << "================>Norm *\n"<<"\n";
	cout << "||p1||\n" << SqNorm(p1)<<"\n";
	cout << "\n||p2||\n" << SqNorm(p2)<<"\n";
	cout << "\n||p3||\n" << SqNorm(p3)<<"\n";
	cout << "\n||p4||\n" << SqNorm(p4)<<"\n";
	cout << "\n||p12||\n" << SqNorm(p12)<<"\n";
	cout << "\n||p13||\n" << SqNorm(p13)<<"\n";
	cout << "\n||p11||\n" << SqNorm(p11)<<"\n";
	cout << "\n||p10||\n" << SqNorm(p10)<<"\n";
	cout << "================>SqDist *\n"<<"\n";
	cout << "||p1-p1||\n" << SqDistance(p1,p1)<<"\n";
	cout << "\n||p2-p1||\n" << SqDistance(p2,p1)<<"\n";
	cout << "\n||p1-p2||\n" << SqDistance(p1,p2)<<"\n";
	cout << "\n||p9-10||\n" << SqDistance(p9,p10)<<"\n";
	cout << "\n||p10-p9||\n" << SqDistance(p10,p9)<<"\n";
	cout << "\n||p13-p12||\n" << SqDistance(p13,p12)<<"\n";
	cout << "\n||p12-p13||\n" << SqDistance(p12,p13)<<"\n";
	cout << "\n||p10-p10||\n" << SqDistance(p10,p10)<<"\n";
	cout << "\n||p2,p13||\n" << SqDistance(p2, p13)<<"\n";

	cout << "\n\n\n\n\n"<<"\n";

	cout << "---------------------Complex Check ---------------------\n"<<"\n";
	cout << "================>Print\n"<<"\n";
	complex c1(0, 0);
	complex c2(1, 0);
	complex c3(0, 1);
	complex c4(2, 0);
	complex c5(0, 2);
	complex c6(2, 2);
	complex c7(-1, -1);
	complex c8(-1, 0);
	complex c9(0, -1);
	complex c10(2, -1);
	complex c11(-1, 2);
	complex c12(-1, 0);
	complex c13(-332, -200);
	//Default Constructor check
	complex c14(1);
	complex c15;

	cout << c1 << "\n" << c2 << "\n" << c3 << "\n" << c4 << "\n" << c5 << "\n" << c6 << "\n" << c7 << "\n" << c8 << "\n" << c9 << "\n" << c10 << "\n" << c11 << "\n" << c12 << "\n" << c13 << "\n" << c14 << "\n" << c15<<"\n";

	cout << "================>Conj\n"<<"\n";
	cout << conj(c1) << "\n" << conj(c2) << "\n" << conj(c3) << "\n" << conj(c4) << "\n" << conj(c5) << "\n" <<
		conj(c6) << "\n" << conj(c7) << "\n" << conj(c8) << "\n" << conj(c9) << "\n" << conj(c10) << "\n" << conj(c11) << "\n" << conj(c12) << "\n" << conj(c13) << "\n" <<"\n";
	cout << "================>Op +\n"<<"\n";
	cout << c1 + c2 << "\n" << c2 + c3 << "\n" << c3 + c4 << "\n" << c4 + c5 << "\n" << c5 + c6 << "\n" << c6 + c7 << "\n" << c7 + c8 << "\n" << c13 +c13 << "\n" <<"\n";
	cout << "================>Op -\n"<<"\n";
	cout << c1 - c2 << "\n" << c2 - c3 << "\n" << c3 - c4 << "\n" << c4 - c5 << "\n" << c5 - c6 << "\n" << c6 - c7 << "\n" << c7 - c8 << "\n" << c13 - c13 << "\n" <<"\n";
	cout << "================>Op *\n"<<"\n";
	cout << c1 * c2 << "\n" << c2 * c3 << "\n" << c3 * c4 << "\n" << c4 * c5 << "\n" << c5 * c6 << "\n" << c6 * c7 << "\n" << c7 * c8 << "\n" << c13 * c13 << "\n" <<"\n";
	
	//cout << "================>Scalar Multiply\n"<<"\n";
	//cout << 0* c2 << 1* c3 << 2* c4 << 3* c5 << 4 * c6 << 5 * c7 <<6 * c8 << 7 * c13<<"\n";
	
	//cout << "================>Op +=\n"<<"\n";
	//cout << c1;
	//c1 += c2; cout << "\n"; cout << c1 << "\n";  c1 += c3; cout << "\n"; cout << c1 << "\n"; c1 += c3; cout << "\n"; cout << c1 << "\n"; c1 += c13; cout << "\n"; cout << c1 << "\n";
	
	
	cout << "================>Inner Product\n"<<"\n";
	cout << InnerProduct(c1, c2) << "\n" << InnerProduct(c2, c3) << "\n" << InnerProduct(c3, c4) << "\n" << InnerProduct(c6, c7) << "\n" << InnerProduct(c10, c13) <<"\n";
	cout << "================>Norm\n"<<"\n";
	cout << SqNorm(c1) << "\n" << SqNorm(c2) << "\n" << SqNorm(c3) << "\n" << SqNorm(c4) << "\n" << SqNorm(c5) << "\n" << SqNorm(c6) << "\n" << SqNorm(c7) << "\n" << SqNorm(c13) <<"\n";
	cout << "================>Sq Dist\n"<<"\n";
	cout << SqDistance(c1, c2) << "\n" << SqDistance(c2, c3) << "\n" << SqDistance(c3, c4) <<  "\n" << SqDistance(c10, c13) <<"\n";
	
	return 0;
}
