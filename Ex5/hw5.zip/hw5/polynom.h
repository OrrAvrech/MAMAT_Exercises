#ifndef _POLY_F
#define _POLY_F
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <iostream>

using namespace std;

class polynom;
std::ostream& operator<<(std::ostream&, const polynom&);
int InnerProduct(const polynom&, const polynom&);
int SqNorm(const polynom&);
int SqDistance(const polynom&, const polynom&);

class polynom  {
public:
	polynom(int n=0, int* coefs=NULL);
	polynom(const polynom&);
	~polynom();
	polynom& operator=(const polynom&);
	friend polynom operator+(const polynom&, const polynom&);
	friend polynom operator-(const polynom&, const polynom&);
	friend polynom operator*(const polynom&, const polynom&);
	friend polynom operator*(int scalar, const polynom& p2);
	friend std::ostream& operator<<(std::ostream&, const polynom&);
	int GetOrder() const;
	int* GetCoefs();
protected:
	polynom& fixOrder();
	int n_;
	int* coefs_;
};

//*********************************************************************************************************
//* function name:	InnerProduct
//* Description  :	Return the inner product between two polynoms.
//*					Meaning, integral from 0 to 1 of P(x)*Q(x)
//* Parameters   :	p1 - the first polynom P(x)
//*					p2 - the second polynom Q(x)
//* Return Value :	result - integer number
//*********************************************************************************************************
inline int InnerProduct(const polynom& p1, const polynom& p2) {
	if (p1.GetOrder() == -1 || p2.GetOrder() == -1) return 0; // case one of them is P(x) = 0
	polynom integrand = p1*p2; // P(x)*Q(x)
	int n = integrand.GetOrder();
	int* coefs = integrand.GetCoefs();
	double result = 0;
	for (int i = 0; i < n + 1; i++)
		result += static_cast<double>(coefs[i]) / (i+1); // integral [P(x)*Q(x)]dx and sum the coefs
	delete [] coefs;
	return static_cast<int>(result);
}

//*********************************************************************************************************
//* function name:	SqNorm
//* Description  :	Return the square norm of a polynum. Meaning, for ||P(x)||^2
//* Parameters   :	p - the polynom P(x)
//* Return Value :	result (integer)
//*********************************************************************************************************
inline int SqNorm(const polynom& p) {
	return InnerProduct(p,p);
}

//*********************************************************************************************************
//* function name:	SqDistance
//* Description  :	Return the square distance between two polynoms. Meaning, ||P(x)-Q(x)||^2
//* Parameters   :	p1 - the first polynom P(x)
//*					p2 - the second polynom Q(x)
//* Return Value :	result (integer)
//*********************************************************************************************************
inline int SqDistance(const polynom& p1, const polynom& p2) {
	polynom result = p1 - p2; 
	return SqNorm(result);
}

#endif
 
