#include "polynom.h"

polynom::polynom(int n, int* coefs) : n_(n) {
	coefs_ = new int[n+1];
	if (coefs)
		for (int i = 0; i < n_ + 1; i++)
			coefs_[i] = coefs[i];
}

polynom::~polynom() {
	delete[] coefs_;
}

polynom& polynom::operator=(const polynom& other) {
	if (n_ != other.n_) {
		delete[] coefs_;
		n_ = other.n_;
		coefs_ = new int[n_+1];
	}
	for (int i = 0; i < n_+1; i++)
		coefs_[i] = other.coefs_[i];
	return (*this);
}

int polynom::GetOrder() const{
	return n_;
}

int* polynom::GetCoefs() {
	int* calc(new int[n_+1]);
	for (int i = 0; i < n_+1; i++)	
		calc[i] = coefs_[i];
	return calc;
}

polynom operator+(const polynom& p1, const polynom& p2) {
	int p1_order = p1.GetOrder();
	int p2_order = p2.GetOrder();
	int size = (p1_order > p2_order) ? p2_order : p1_order; // get the minimum order
	//if ((p1_order == p2_order) && ((p1.GetCoefs)[p1_order] + p2.coefs_(p2_order) == 0))
	polynom tmp;
	if (p1_order > p2_order) tmp = p1;
	else tmp = p2;
	for (int i = 0; i < size; i++)
		tmp.coefs_[i] = p1.coefs_[i] + p2.coefs_[i];
	size = tmp.GetOrder(); // get the new polynom order	
	while (tmp.coefs_[size + 1] == 0) size--;  // find the correct order of the polynum
	polynom result(size+1);
	for (int i = 0; i < size+1; i++) result.coefs_[i] = tmp.coefs_[i];
	return result;
}

polynom operator-(const polynom& p1, const polynom& p2) {
	int p1_order = p1.GetOrder();
	int p2_order = p2.GetOrder();
	int size = (p1_order > p2_order) ? p2_order : p1_order; // get the minimum order
	//if ((p1_order == p2_order) && ((p1.GetCoefs)[p1_order] + p2.coefs_(p2_order) == 0))
	polynom tmp;
	if (p1_order > p2_order) tmp = p1;
	else tmp = p2;
	for (int i = 0; i < size; i++)
		tmp.coefs_[i] = p1.coefs_[i] - p2.coefs_[i];
	size = tmp.GetOrder(); // get the new polynom order	
	while (tmp.coefs_[size + 1] == 0) size--;  // find the correct order of the polynum
	polynom result(size + 1);
	for (int i = 0; i < size + 1; i++) result.coefs_[i] = tmp.coefs_[i];
	return result;
}

polynom operator*(const polynom& p1, const polynom& p2) {
	int m = p1.GetOrder();
	int n = p2.GetOrder();
	polynom result(m + n);

	for (int k=0; k< m+n;k++)
		for (int l = 0; l < k; l++)
			result.coefs_[k] = p1.coefs_[l] * p2.coefs_[l-k];
	return result;
}

polynom operator*(int scalar, const polynom& p1) {
	int n = p1.GetOrder();
	polynom result = p1;
	for (int i = 0; i < n+1; i++)
		result.coefs_[i] *= scalar;
		
	return result;
}

std::ostream& operator<<(std::ostream& os_, const polynom& p) {
	int n = p.GetOrder();
	bool zero_p = true; // check if p(x) = 0
	for (int i = 0; i < n + 1; i++)
		if (p.coefs_[i]) zero_p = false;
	if (zero_p == true) return os_ << "0"; // case it's p(x) = 0
	for (int i = n + 1; i > 0 ;i--)
		if (p.coefs_[i]) os_ << p.coefs_[i] << "x^" << p.coefs_[i] + 1;
	return os_;
}

int InnerProduct(const polynom& p1, const polynom& p2) {
	polynom integrand = p1*p2; // P(x)*Q(x)
	polynom poly_1; // p(x) = x
	integrand = integrand*poly_1;
	int n = integrand.GetOrder();

	for (int i = 1; i < n + 1; i++)
		integrand.coefs_[i] = integrand.coefs_[i] / i;
	// so far we did: integral [P(x)*Q(x)]dx
	int result = 0;
	for (int i = 0; i < n + 1; i++)
		result += integrand.coefs_[i] * integrand.coefs_[i];
	return result;
}

int SqNorm(const polynom& p) {
	int norm=0;
	int n = p.GetOrder();
	for (int i = 0; i < n + 1; i++)
		norm += (p.coefs_[i] * p.coefs_[i]);
	return norm;
}

int SqDistance(const polynom& p1, const polynom& p2) {
	polynom result = p1 - p2;
	return SqNorm(result);
}
