/* flight.c */

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 

#include "ex2.h"
#include "flight.h"

BOOL isUpperCase(const char *String)
{
	int i;
	int n = strlen(String);
	for (i = 0; i < n; i++)
		if (!(String[i] >= 'A' && String[i] <= 'Z'))
			return FALSE;
	return TRUE;
}
  
PFLIGHT createFlight(int id , FlightType flight_type , char* dest, BOOL emergency){
  // 
  PFLIGHT pFlight = NULL;
  if (id <= 0 || (flight_type != DOMESTIC && flight_type != INTERNATIONAL)
	  || (dest == NULL || strlen(dest) != NUM_DEST_LETTERS || !isUpperCase(dest))
	  || (emergency != TRUE && emergency != FALSE))
	  return pFlight; // illegal parameters
  if ((pFlight = (PFLIGHT) malloc(sizeof(FLIGHT)))){
    pFlight->flight_id = id;
    pFlight->ftype = flight_type;
    strcpy(pFlight->dest, dest);
    pFlight->emergency = emergency;
  }
  return pFlight;
}

void destroyFlight(PFLIGHT pFlight){
  //
  free(pFlight);
}

Result printFlight(PFLIGHT pFlight) {
  //
  if (pFlight != NULL){
    char dest_type;
    char flight_urgence;
	dest_type = (pFlight->ftype == DOMESTIC) ? 'D' : 'I';
	flight_urgence =(pFlight->emergency == TRUE) ? 'E' : 'R';
    printf("Flight %d %c %s %c\n", pFlight->flight_id, dest_type, pFlight->dest, flight_urgence);
    return SUCCESS;
    }
  return FAILURE;
}