#include <iostream>
#include "Message.H"

Message::Message(string source, string subject, string content) : source_(source), subject_(subject), content_(content), read_(false) {}

void Message::Display(int num) const
{
	cout << num << ") "<< (read_ ? "" : "(Unread) ") << "From: " << source_ << endl;
	cout << "Subject: " << subject_ << endl;
}

void Message::Read()
{
    read_ = true;
	cout << "From: " << source_ << endl;
	cout << "Subject: " << subject_ << endl;
	cout << "Content: " << content_ << endl;
}

bool Message::isRead()
{
	return read_;
}

MessageBox :: MessageBox() {
	//MessageBox_= MESSAGE;//??? no need to write nothing
	Total_Message_ = 0;
	Unread_Message_ = 0;
}

MessageBox::~MessageBox() {                   //already defined
		Message* head=MessageBox_.goHead();
		Message* iterator;
	while (head != NULL) {
		iterator = head->next;
		delete ((Message*)(head.getValue()));
		head = iterator;
	}
}

void MessageBox::Add(Message newMessage) {
	MessageBox_.add(new Message(newMessage));// the new type 
	Total_Message_++;
	Unread_Message_++;
}

int Size()
{
	return Total_Message_;
}

int UnreadSize()
{
	return Unread_Message_;
}

void MessageBox::Print() {
		Message* head=MessageBox_.goHead();
		Message* iterator;
		int size=1;
	while (head != NULL) {
		iterator = head->next;
		Message* tmp = (Message*)(MessageBox_.getValue());
		tmp->Display(size);
		head = iterator;
	}
}

Result MessageBox::ReadMessage(int messageNum) {
	if (messageNum < 0 || messageNum > MessageBox_.getValue())
		return FAILURE;
	
		Message* head=MessageBox_.goHead();
		Message* iterator;
	while (head != NULL) {
		iterator = head->next;
		Message* tmp = (Message*)(MessageBox_.getValue());
		if tmp->isRead()== false
			Unread_Message_--;
			tmp->read	//read it also
		head = iterator;
	}
	return SUCCESS;
}