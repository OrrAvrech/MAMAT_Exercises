/* runway.h - interface to an ADT which implements a runway */

#ifndef RUNWAY_H_
#define RUNWAY_H_

typedef struct node_t { // linked list of flights
	PFLIGHT pFlight;
	struct node_t* next;
} NODE;

typedef struct runway_t {
	int runway_id;
	FlightType run_type;
	NODE* head; // head of the linked list //
	int num_of_flights;
}RUNWAY, *PRUNWAY;

PRUNWAY createRunway(int id , FlightType run_type);
void destroyRunway(PRUNWAY pRunway);
BOOL isFlightExists(PRUNWAY pRunway, int id);
int getFlightNum(PRUNWAY pRunway);
Result addFlight(PRUNWAY pRunway, PFLIGHT pFlight); // need to COPY the flight?
Result removeFlight(PRUNWAY pRunway, int id);
Result depart(PRUNWAY pRunway);
Result printRunway(PRUNWAY pRunway);

#endif /* RUNWAY_H_ */