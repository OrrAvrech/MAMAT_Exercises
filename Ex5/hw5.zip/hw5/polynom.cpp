#include "polynom.h"


//*********************************************************************************************************
//* function name:	polynom
//* Description  :	Constructor of a polynom class. 
//* Parameters   :	n - order of polynom ( default: 0)
//*					coefs - a int pointer to the array of coefs of the polynum( default: NULL )
//* Return Value :	None
//*********************************************************************************************************
polynom::polynom(int n, int* coefs) : n_(n){
	if (n != -1) coefs_ = new int[n + 1]; // case P(x) = 0
	if (coefs)
		for (int i = 0; i < n_ + 1; i++)
			coefs_[i] = coefs[i];
}

//*********************************************************************************************************
//* function name:	polynom
//* Description  :	Constructor of a polynom class( copy a already existing polynum 
//* Parameters   :	p - a polynum to copy from
//* Return Value :	None
//*********************************************************************************************************
polynom::polynom(const polynom& p) : n_(p.n_), coefs_(new int[p.n_ + 1]) {
	for (int i = 0; i < p.n_ + 1; i++)
		coefs_[i] = (p.coefs_[i]);
}

//*********************************************************************************************************
//* function name:	~polynom
//* Description  :	Destructor of a polynom class. 
//* Parameters   :	None
//* Return Value :	None
//*********************************************************************************************************
polynom::~polynom() {
	delete[] coefs_;
}

//*********************************************************************************************************
//* function name:	operator=
//* Description  :	= operator
//* Parameters   :	p - a polynom
//* Return Value :	the assignment
//*********************************************************************************************************
polynom& polynom::operator=(const polynom& p) {
	if (this != &p) {
		delete[] coefs_;
		n_ = p.n_;
		coefs_ = new int[n_ + 1];
		for (int i = 0; i < n_ + 1; i++)
			coefs_[i] = p.coefs_[i];
	}
	return (*this);
}

//*********************************************************************************************************
//* function name:	GetOrder
//* Description  :	Returns the order(degree) of the polynum
//* Parameters   :	None
//* Return Value :	n_ - (integer) of the polynom
//*********************************************************************************************************
int polynom::GetOrder() const{
	return n_;
}

//*********************************************************************************************************
//* function name:	GetCoefs
//* Description  :	Returns a pointer to a copy of the coefs array
//* Parameters   :	None
//* Return Value :	calc - a pointer to the aray
//*********************************************************************************************************
int* polynom::GetCoefs() {
	int* calc = new int[n_ + 1];
	for (int i = 0; i < n_ + 1; i++)
		calc[i] = coefs_[i];
	return calc;
}

//*********************************************************************************************************
//* function name:	fixOrder
//* Description  :	Fix the order of the polynum(reduces the order and delete coefs of leading zeros
//*					example: 0*x^3+0*x^2+1 will turn to x^2+1 (order of 2)
//* Parameters   :	None
//* Return Value :	None ( fix the polynum the function is activated on)
//*********************************************************************************************************
polynom& polynom::fixOrder() {
	int order = n_;
	while (order != -1 && coefs_[order] == 0) order--;  // find the correct order of the polynum
	if (order == -1) {// P(x) = 0
		delete[] coefs_;
		n_ = -1;
		coefs_ = NULL;
		return *this;
	}
	int* tmp = new int[order + 1];
	for (int i = 0; i < order + 1; i++)
		tmp[i] = coefs_[i];
	delete[] coefs_;
	coefs_ = tmp;
	n_ = order;
	return *this;
}

//*********************************************************************************************************
//* function name:	operator+
//* Description  :	Operater+ for two polynoms P(x)+Q(x)
//* Parameters   :	p1 - the first polynom P(x)
//*					p2 - the second polynom Q(x)
//* Return Value :	result (polynum)
//*********************************************************************************************************
polynom operator+(const polynom& p1, const polynom& p2) {
	int p1_order = p1.GetOrder();
	int p2_order = p2.GetOrder();
	int size = (p1_order > p2_order) ? p1_order : p2_order; // get the max order
	polynom result;
	if (p1_order > p2_order) result = p1;
	else result = p2;
	for (int i = 0; i < size + 1; i++){
		result.coefs_[i] = 0;
		if (i <= p1_order) result.coefs_[i] = p1.coefs_[i];
		if (i <= p2_order) result.coefs_[i] += p2.coefs_[i];
	}
	result.fixOrder();
	return result;
}

//*********************************************************************************************************
//* function name:	operator-
//* Description  :	Operater- for two polynoms P(x)-Q(x)
//* Parameters   :	p1 - the first polynom P(x)
//*					p2 - the second polynom Q(x)
//* Return Value :	result (polynum)
//*********************************************************************************************************
polynom operator-(const polynom& p1, const polynom& p2) {
	int p1_order = p1.GetOrder();
	int p2_order = p2.GetOrder();
	int size = (p1_order > p2_order) ? p1_order : p2_order; // get the max order
	polynom result;
	if (p1_order > p2_order) result = p1;
	else result = p2;
	for (int i = 0; i < size + 1; i++) {
		result.coefs_[i] = 0;
		if (i <= p1_order) result.coefs_[i] = p1.coefs_[i];
		if (i <= p2_order) result.coefs_[i] -= p2.coefs_[i];
	}
	result.fixOrder();
	return result;
}

//*********************************************************************************************************
//* function name:	operator*
//* Description  :	Operater* for two polynoms P(x)*Q(x)
//* Parameters   :	p1 - the first polynom P(x)
//*					p2 - the second polynom Q(x)
//* Return Value :	result (polynum)
//*********************************************************************************************************
polynom operator*(const polynom& p1, const polynom& p2) {
	int m = p1.GetOrder();
	int n = p2.GetOrder();
	int size = (m+n > -2) ? m+n : -1; // case 0*0
	polynom result(size);
	for (int i = 0; i <= size; i++)
		result.coefs_[i] = 0;
	for (int k=0; k<=m;k++)
		for (int l = 0; l <= n; l++)
			result.coefs_[k+l] += p1.coefs_[k] * p2.coefs_[l];
	result.fixOrder();
	return result;
}

//*********************************************************************************************************
//* function name:	operator*
//* Description  :	Operater* for a scalar(integer) with a polynom a*Q(x)
//* Parameters   :	scalar - the scalar(int)
//*					p1 - the polynom P(x)
//* Return Value :	result (polynum)
//*********************************************************************************************************
polynom operator*(int scalar, const polynom& p1) {
	int n = p1.GetOrder();
	polynom result = p1;
	for (int i = 0; i < n+1; i++)
		result.coefs_[i] *= scalar;
	result.fixOrder();
	return result;
}

//*********************************************************************************************************
//* function name:	operator<<
//* Description  :	Print a polynum number in the format: an*x^n+an-1*x^n-1+....+a0
//*					Prints "0" for P(x) = 0 
//* Parameters   :	target - a polynum
//* Return Value :	the ostream
//*********************************************************************************************************
std::ostream& operator<<(std::ostream& os_, const polynom& target) {
	polynom p = target;
	p.fixOrder();
	int n = p.GetOrder();
	if (n == -1) return os_ << "0"; // case it's p(x) = 0
	for (int i = n; i > 1; i--) { // handles until degree 2
		if (p.coefs_[i]) {
			if (p.coefs_[i] == -1) os_ << "-x^" << i;
			else if (p.coefs_[i] < 0 ) os_ << p.coefs_[i] << "x^" << i; 
			else if (n == i && p.coefs_[i] == 1) os_ << "x^" << i;
			else if (n == i) os_ << p.coefs_[i] << "x^" << i;
			else if (p.coefs_[i] == 1) os_ << "+" << "x^" << i;
			else os_ << "+" << p.coefs_[i] << "x^" << i;
		}
	}
	if (n > 0 && p.coefs_[1]) { // degree 1, a1*x
		if (p.coefs_[1] == -1) os_ << "-x";
		else if (p.coefs_[1] < 0) os_ << p.coefs_[1] << "x";
		else if (n == 1 && p.coefs_[1] == 1) os_ << "x";
		else if (n == 1) os_ << p.coefs_[1] << "x";
		else if (p.coefs_[1] == 1) os_ << "+" << "x";
		else os_ << "+" << p.coefs_[1] << "x";
	}
	if (p.coefs_[0]) { // degree 0, a0
		if (n == 0 || p.coefs_[0] < 0) os_ << p.coefs_[0]; // p(x) = a0 or a0 < 0
		else os_ << "+" << p.coefs_[0];
	}
	return os_;
}

