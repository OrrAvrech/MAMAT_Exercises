#include <iostream>
#include "complex.h"

using namespace std;

//*********************************************************************************************************
//* function name:	complex
//* Description  :	Constructor of complex class
//* Parameters   :	re - the real part 
//*					im - the imaginary part
//* Return Value :	None
//*********************************************************************************************************
//complex::complex(int re, int im) :
//	re_(re), im_(im){};

//*********************************************************************************************************
//* function name:	GetReal
//* Description  :	Get the real value of a complex number
//* Parameters   :	z - the complex number
//* Return Value :	The real part
//*********************************************************************************************************
int complex::GetReal() const{
	return re_;
}

//*********************************************************************************************************
//* function name:	GetIM
//* Description  :	Get the imaginary value of a complex number
//* Parameters   :	z - the complex number
//* Return Value :	The imaginary part
//*********************************************************************************************************
int complex::GetIM() const {
	return im_;
}


//*********************************************************************************************************
//* function name:	operator=
//* Description  :	= operator
//* Parameters   :	z - the complex number
//* Return Value :	the asama
//*********************************************************************************************************
complex& complex::operator=(const complex& z) {
	if (this != &z) {
		re_ = z.re_;
		im_ = z.im_;
	}
	return (*this);
}


//*********************************************************************************************************
//* function name:	operator+
//* Description  :	Operater+ for two complex numbers
//* Parameters   :	c1 - the first complex number
//*					c2 - the second complex number
//* Return Value :	c - the result (complex number)
//*********************************************************************************************************
complex operator+(const complex& c1, const complex& c2) {
	complex c(c1.re_ + c2.re_, c1.im_ + c2.im_);
	return c;
}

//*********************************************************************************************************
//* function name:	operator-
//* Description  :	Operater- for two complex numbers
//* Parameters   :	c1 - the complex number to substract from
//*					c2 - the complex number to substract with
//* Return Value :	c - the result (complex number)
//*********************************************************************************************************
complex operator-(const complex& c1, const complex& c2) {
	complex c(c1.re_ - c2.re_, c1.im_ - c2.im_);
	return c;
}

//*********************************************************************************************************
//* function name:	operator*
//* Description  :	Operater* for two complex numbers
//* Parameters   :	c1 - the first complex number
//*					c2 - the second complex number
//* Return Value :	c - the result (complex number)
//*********************************************************************************************************
complex operator*(const complex& c1, const complex& c2) {
	int a = (c1.re_), b = (c1.im_), c = (c2.re_), d = (c2.im_);
	complex z((a*c - b*d), (a*d + b*c));
	return z;
}

//*********************************************************************************************************
//* function name:	operator<<
//* Description  :	Print a complex number in the format: a+bi or a (if b = 0) or bi(if a = 0)
//* Parameters   :	z - a complex number
//* Return Value :	the ostream
//*********************************************************************************************************
std::ostream& operator<<(std::ostream& os_, const complex& z) {
	if (z.GetReal()) {
		if (z.GetIM())
			if (z.GetIM() == 1) return os_ << z.GetReal() << "+i"; // case a + i
			else if (z.GetIM() == -1) return os_ << z.GetReal() << "-i"; // case a - i
			else return os_ << z.GetReal() << z.GetIM() << "i"; // case a+bi
			return os_ << z.GetReal(); // case a
	}
	else if (z.GetIM())
		if (z.GetIM() == 1) return os_ << "i"; // case i
		else if (z.GetIM() == -1) return os_ << "-i"; // case - i
		else return os_ << z.GetIM() << "i";  // case bi
		return os_ << "0"; // case z = 0 
}

//*********************************************************************************************************
//* function name:	conj
//* Description  :	Return the conjugate of the complex number. Meaning, for z=a+ib return z_=a-ib
//* Parameters   :	None
//* Return Value :	c - the result (complex number)
//*********************************************************************************************************
complex complex::conj() const{
	complex c(re_ , -1 * im_);
	return c;
}


