/* runway.c */

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 

#include "ex2.h"
#include "flight.h"
#include "runway.h"


PRUNWAY createRunway(int id , FlightType run_type){
//
	PRUNWAY pRunway = NULL;
	if (id <= 0)
		return pRunway;
	if ((pRunway = (PRUNWAY) malloc(sizeof(RUNWAY)))){
		pRunway-> runway_id = id;
		pRunway-> run_type = run_type;
		pRunway-> num_of_flights = 0;
		pRunway-> head = NULL; // no flights on runway
	}
	return pRunway;
}

void destroyRunway(PRUNWAY pRunway){ 
//
	if (pRunway == NULL)
		return; // pointer is empty
	NODE* tmp;
	tmp = pRunway->head;
	while (tmp!=NULL ){ // destroy all COPIES of flights on the runway
		//destroyFlight(tmp->pFlight); 
		//tmp=tmp->next;
		NODE* requested_node = tmp;
		destroyFlight(tmp->pFlight); 
		tmp = tmp->next;
		free(requested_node);
	}
	free(pRunway);
}

BOOL isFlightExists(PRUNWAY pRunway, int id){
//
	if (pRunway == NULL || id <= 0 || pRunway->head == NULL)
		return FALSE; // Runway pointer is empty or flight number is not a positive number
	NODE* tmp;
	for (tmp = pRunway->head;tmp;tmp=tmp->next)  // check all flights on the runway list
		if (tmp->pFlight->flight_id == id)
			return TRUE;
	return FALSE; // flight not found
}

int getFlightNum(PRUNWAY pRunway){
//
	if (pRunway == NULL)
		return -1; // illegal runway id
	return pRunway->num_of_flights;
}


Result addFlight(PRUNWAY pRunway, PFLIGHT pFlight){  // need to COPY the flight
//
	if (pRunway == NULL || pFlight == NULL )
		return FAILURE; // illegal pointer
	if (pRunway->run_type != pFlight->ftype)
		return FAILURE; // flight type isn't the same of runway type
	NODE* tmp;
	tmp = pRunway->head;
	if (isFlightExists(pRunway, pFlight->flight_id))// flight already exists on runway
		return FAILURE;
	if (pRunway->num_of_flights == 0 ){
		// case it's the first flight on runway
		tmp = (NODE*)malloc(sizeof(NODE));
		tmp->pFlight = createFlight(pFlight->flight_id , pFlight->ftype , pFlight->dest, pFlight->emergency);
		tmp->next = NULL;
		pRunway->head = tmp;
		(pRunway->num_of_flights)++;
		return SUCCESS;
	}
	if (tmp->pFlight->emergency == FALSE && pFlight->emergency == TRUE) {
		// case the first flight is REGULAR and entering is EMERGENCY
		NODE* tmp_emer=(NODE*)malloc(sizeof(NODE));
		tmp_emer->pFlight = createFlight(pFlight->flight_id, pFlight->ftype, pFlight->dest, pFlight->emergency);
		tmp_emer->next = tmp;
		pRunway->head = tmp_emer;
		(pRunway->num_of_flights)++;
		return SUCCESS;
	}

	while (tmp->next != NULL && tmp->next->pFlight->emergency == TRUE)
		tmp=tmp->next; // goes until the first regular flight or until list ends
	if (pFlight->emergency == TRUE){
		// case when emergency flight or no other flights on runway
		NODE* current_next = tmp->next;
		tmp->next = (NODE*)malloc(sizeof(NODE));
		tmp->next->pFlight = createFlight(pFlight->flight_id, pFlight->ftype, pFlight->dest, pFlight->emergency);
		tmp->next->next = current_next; // re-links to the next flight
		(pRunway->num_of_flights)++;
		return SUCCESS;
		}
	while (tmp->next != NULL) 
		// case when there are regular flights
		tmp=tmp->next; // goes to the end of the list
	
	tmp->next = (NODE*)malloc(sizeof(NODE));
	tmp->next->pFlight = createFlight(pFlight->flight_id , pFlight->ftype , pFlight->dest, pFlight->emergency);
	tmp->next->next = NULL; // end of list

	(pRunway->num_of_flights)++;
	return SUCCESS;
}


Result removeFlight(PRUNWAY pRunway, int id){
//
	if (pRunway == NULL)
		return FAILURE; // illegal pointer
	if (isFlightExists(pRunway, id) == FALSE)
		return FAILURE; // flight isn't on runway
	NODE* tmp;
	tmp = pRunway->head;
	
	if (tmp->pFlight->flight_id == id){
		// case it's the first flight
		destroyFlight(tmp->pFlight); 
		pRunway->head = tmp->next;
		free(tmp);
		(pRunway->num_of_flights)--;
		return SUCCESS;
	}
	
	while (tmp->next->pFlight->flight_id != id)
		// case elsewise
		tmp=tmp->next; // goes to the flight linked before to the requested flight
	NODE* requested_node = tmp->next;
	destroyFlight(requested_node->pFlight);
	tmp->next = tmp->next->next;
	free(requested_node);
	(pRunway->num_of_flights)--;
	return SUCCESS;
}


Result depart(PRUNWAY pRunway){ 
//
	if (pRunway == NULL)
		return FAILURE; // illegal pointer
	if (pRunway->num_of_flights == 0)
		return FAILURE; // no flights on runway
	NODE* tmp;
	tmp = pRunway->head;
	destroyFlight(tmp->pFlight); 
	pRunway->head = tmp->next;
	free(tmp);
	(pRunway->num_of_flights)--;
	return SUCCESS;
}


Result printRunway(PRUNWAY pRunway){
//
	if (pRunway != NULL){
		printf("Runway %d ", pRunway->runway_id);
		char run_type;
		run_type =( pRunway->run_type == DOMESTIC) ? 'D' : 'I';
		if (run_type == 'D')
			printf("domestic\n");
		else
			printf("international\n");
		printf("%d flights are waiting:\n", pRunway->num_of_flights);
		NODE* tmp;
		tmp = pRunway->head;
		while (tmp!=NULL){ 
			char flight_urgence;
			flight_urgence =(tmp->pFlight->emergency == TRUE) ? 'E' : 'R';
			printf("Flight %d %c %s %c\n", tmp->pFlight->flight_id, run_type, tmp->pFlight->dest, flight_urgence);
			tmp=tmp->next;
		}
		return SUCCESS;
		}
  return FAILURE;
}


