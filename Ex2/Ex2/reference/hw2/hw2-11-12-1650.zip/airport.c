/* runway.c */

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 

#include "ex2.h"
#include "flight.h"
#include "runway.h"
#include "airport.h"

static PNODEAIR Airport = NULL;
BOOL isFlightExistsDest(PRUNWAY pRunway, char* dest);
Result CopyFlightsStorm(PRUNWAY pRunway1, PRUNWAY pRunway2, char* dest);
Result readdStormFlights(PRUNWAY pRunway1, PRUNWAY pRunway2, char* dest);

PNODEAIR CreateAirport() {
	//
	if ((Airport = (PNODEAIR)malloc(sizeof(NODEAIR)))) {
		Airport->next = NULL;
		Airport->pRunway = NULL;
	}
	return Airport;
}

BOOL isRunwayExists(int id) {
	//
	PNODEAIR tmp = Airport;
	while (tmp != NULL) {
		if (tmp->pRunway->runway_id == id) { return TRUE; } // runway with the same id exists
		tmp = tmp->next;
	}
	return FALSE;
}

Result addRunway(int id, FlightType run_type) {
	//
	if (Airport == NULL) {  // airport does not exist
		Airport = CreateAirport();
	}
	if (id <= 0 || ((run_type != DOMESTIC) && (run_type != INTERNATIONAL)))
		return FAILURE; // illegal parameters
	PNODEAIR tmp;
	tmp = Airport;
	if (tmp->pRunway == NULL) {// adding first runway
		tmp->pRunway = createRunway(id, run_type);
		return SUCCESS;
	}

	if ((isRunwayExists(id)) == TRUE)
		return FAILURE; // runway with the same id already exists

	while (tmp->next != NULL) {
		if (tmp->pRunway->runway_id == id)
			return FAILURE; // a runway with the same id already exists
		else
			tmp = tmp->next;
	}
	tmp->next = (PNODEAIR)malloc(sizeof(NODEAIR));
	tmp->next->pRunway= createRunway(id, run_type);
	tmp->next->next = NULL;
	return SUCCESS;
}

Result removeRunway(int id) {
	//
	if (Airport == NULL)
		return FAILURE; // airport doesn't exist
	if (id <= 0)
		return FAILURE; // illegal parameters
	PNODEAIR tmp;
	tmp = Airport;
	if (tmp->pRunway->runway_id == id) {
		// case first runway
		destroyRunway(tmp->pRunway);
		Airport = tmp->next;
		free(tmp);
		return SUCCESS;
	}
	while (tmp->next != NULL) {
		// not first runway
		if (tmp->next->pRunway->runway_id != id)
			tmp = tmp->next;
		else {
			PNODEAIR requested_node = tmp->next;
			destroyRunway(requested_node->pRunway);
			tmp->next = tmp->next->next;
			free(requested_node);
			return SUCCESS;
		}
	}
	return FAILURE;
}


Result addFlightToAirport(int id, FlightType flight_type, char* dest, BOOL emergency) {
	//
	PFLIGHT pFlight;
	PNODEAIR tmp = Airport;
	if (Airport == NULL || tmp->pRunway == NULL)
		return FAILURE;
	if (id <= 0 || ((flight_type != DOMESTIC) && (flight_type != INTERNATIONAL))
		|| (dest == NULL || strlen(dest) != NUM_DEST_LETTERS || !isUpperCase(dest))
		|| (emergency != TRUE && emergency != FALSE))
		return FAILURE; // illegal parameters
	while (tmp != NULL) {
		if (isFlightExists(tmp->pRunway, id)) { return FAILURE; } //checks if flight exists in Airport
		tmp = tmp->next;
	}
	if ((pFlight = createFlight(id, flight_type, dest, emergency)) == NULL)
		return FAILURE; // creating flight failed
	int minimum_flights = -1;
	PRUNWAY target = NULL;
	tmp = Airport;
	while (tmp != NULL) {
		if (tmp->pRunway->run_type == flight_type) {
			if (minimum_flights == -1) { // first runway of the same flight type
				minimum_flights = tmp->pRunway->num_of_flights;
				target = tmp->pRunway;
			}
			if (tmp->pRunway->num_of_flights < minimum_flights) {
				minimum_flights = tmp->pRunway->num_of_flights;
				target = tmp->pRunway;
			}
			else if (tmp->pRunway->num_of_flights == minimum_flights &&
				tmp->pRunway->runway_id < target->runway_id) {
				target = tmp->pRunway;
			}
		}
		tmp = tmp->next;
	}
	if (target == NULL) {
		destroyFlight(pFlight);
		return FAILURE; // no runway to flight
	}
	if (addFlight(target, pFlight) == FAILURE) {
		destroyFlight(pFlight);
		return FAILURE; // failed to alloc flight
	}
	destroyFlight(pFlight);
	return SUCCESS;
}

Result departFromRunway(int id) {
	//
	PNODEAIR tmp = Airport;
	while (tmp != NULL) {
		if (tmp->pRunway->runway_id == id)
			return depart(tmp->pRunway);
		tmp = tmp->next;
	}
	return FAILURE;
}

BOOL isFlightExistsDest(PRUNWAY pRunway, char* dest) {
	//
	if (pRunway == NULL)
		return FALSE; // Runway pointer is empty. Function is called by stormAlert hence dest is legit.
	NODE* tmp;
	for (tmp = pRunway->head; tmp; tmp = tmp->next)  // check all flights on the runway list
		if (!strcmp(tmp->pFlight->dest, dest))
			return TRUE;
	return FALSE;
}

Result CopyFlightsStorm(PRUNWAY pRunway1, PRUNWAY pRunway2, char* dest) {
	//
	if (pRunway1 == NULL || pRunway2 == NULL)
		return FAILURE;
	if (dest == NULL || strlen(dest) != NUM_DEST_LETTERS || !isUpperCase(dest))
		return FAILURE; // illegal destination
	NODE* tmp;
	for (tmp = pRunway1->head; tmp; tmp = tmp->next)  // check all flights on the runway list
		if (!strcmp(tmp->pFlight->dest, dest)) {
			Result res;
			if ((res = addFlight(pRunway2, tmp->pFlight)) == FAILURE)
				return FAILURE;
		}
	return SUCCESS;
}

Result readdStormFlights(PRUNWAY pRunway1, PRUNWAY pRunway2, char* dest) {
	//
	if (pRunway1 == NULL || pRunway2 == NULL)
		return FAILURE;
	NODE* tmp;
	for (tmp = pRunway2->head; tmp; tmp = tmp->next) {
		Result res;
		if ((res = removeFlight(pRunway1, tmp->pFlight->flight_id)) == FAILURE)
			return FAILURE;
		if ((res = addFlight(pRunway1, tmp->pFlight)) == FAILURE)
			return FAILURE;
	}
	return SUCCESS;
}
Result stormAlert(char *dest) {
	//
	
	if (dest == NULL || !isUpperCase(dest) || strlen(dest) != NUM_DEST_LETTERS)
		return FAILURE; // illegal destination
	PNODEAIR tmp = Airport;
	while (tmp != NULL) {
		if (isFlightExistsDest(tmp->pRunway, dest) == TRUE) { // There's a flight to the storm destination
			PRUNWAY ghostRunway = createRunway(1, tmp->pRunway->run_type); 
			// id = 1 is arbitrary, the runway is temp and NOT connected to the airport
			if (CopyFlightsStorm(tmp->pRunway, ghostRunway, dest) == FAILURE)
				return FAILURE;
			if (readdStormFlights(tmp->pRunway, ghostRunway, dest) == FAILURE)
				return FAILURE;
			destroyRunway(ghostRunway);
		}
		tmp = tmp->next;
	}
	return SUCCESS;
}

void printAirport() {
	//
	printf("Airport status:\n");
	PNODEAIR tmp = Airport;
	while (tmp != NULL) {
		printRunway(tmp->pRunway);
		tmp = tmp->next;
	}
	printf("\n");
}

void destroyAirport() {
	//
	PNODEAIR tmp = Airport;
	while (tmp != NULL) {
		removeRunway(tmp->pRunway->runway_id);
		tmp = Airport;
		//tmp = tmp->next;
	}
	free(Airport);
}


