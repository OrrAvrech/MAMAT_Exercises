#ifndef _TEMPVEC_H
#define _TEMPVEC_H

#include <iostream>
#include <string>

using namespace std;
template <class T, int size>
class TempVec {
public:
	TempVec() {};
	TempVec(const TempVec<T, size>&);
	TempVec<T, size>& operator=(const TempVec<T, size>&);
	//*********************************************************************************************************
	//* function name:	operator[]
	//* Description  :	[] operator
	//* Parameters   :	i - the index accessed in the vector
	//* Return Value :	the assignment
	//*********************************************************************************************************
	T& operator[](int i) {
		if (i >= size || i < 0) throw string("Error TempVec. Illegal index");
		return coordinates_[i];
	}
	T operator[](int i) const {
		if (i >= size || i < 0) throw string("Error TempVec. Illegal index");
		return coordinates_[i];
	}
	//*********************************************************************************************************
	//* function name:	operator+
	//* Description  :	Operater+ for two vectors u+v
	//* Parameters   :	vect1 - the first vector
	//*					vect2 - the second vector
	//* Return Value :	result (T, depends on type)
	//*********************************************************************************************************
	friend TempVec<T, size> operator+(const TempVec<T, size>& vect1, const TempVec<T, size>& vect2) {
		TempVec<T, size> result;
		for (int i = 0; i < size; i++) result[i] = vect1[i] + vect2[i];
		return result;
	}
	//*********************************************************************************************************
	//* function name:	operator-
	//* Description  :	Operater- for two vectors u-v
	//* Parameters   :	vect1 - the first vector
	//*					vect2 - the second vector
	//* Return Value :	result (T, depends on type)
	//*********************************************************************************************************
	friend TempVec<T, size> operator-(const TempVec<T, size>& vect1, const TempVec<T, size>& vect2) {
		TempVec<T, size> result;
		for (int i = 0; i < size; i++) result[i] = vect1[i] - vect2[i];
		return result;
	}
	//*********************************************************************************************************
	//* function name:	operator*
	//* Description  :	Operater* for a scalar(integer) with a vector a*vector
	//* Parameters   :	scalar - the scalar(int)
	//*					vect - a vector
	//* Return Value :	result (T, depends on type)
	//*********************************************************************************************************
	friend TempVec<T, size> operator*(T scalar, const TempVec<T, size>& vect) {
		TempVec<T, size> result(vect);
		for (int i = 0; i < size; i++) result[i] = scalar*result[i];
		return result;
	}
	//*********************************************************************************************************
	//* function name:	operator<<
	//* Description  :	Prints a vector
	//* Parameters   :	vect - a vector
	//* Return Value :	the ostream
	//********************************************************************************************************
	friend std::ostream& operator<<(std::ostream& os_, const TempVec<T, size>& vect) {
		os_ << "(";
		for (int i = 0; i < size - 1; i++) os_ << vect.coordinates_[i] << ",";
		return os_ << vect.coordinates_[size - 1] << ")";
	}
protected:
	T coordinates_[size];
};

//*********************************************************************************************************
//* function name:	InnerProduct
//* Description  :	Return the inner product between two integers vectors
//* Parameters   :	vect1 - the first integers vector
//* Parameters   :	vect2 - the first integers vector
//* Return Value :	result (integer)
//*********************************************************************************************************
inline int InnerProduct(const int& vect1, const int& vect2) {
	return vect1*vect2;
}

//*********************************************************************************************************
//* function name:	SqNorm
//* Description  :	Return the square norm of a integers vector. Meaning, for ||u||^2
//* Parameters   :	vect - the integers vector
//* Return Value :	result (integer)
//*********************************************************************************************************
inline int SqNorm(const int& vect) {
	return InnerProduct(vect, vect);
}

//*********************************************************************************************************
//* function name:	SqDistance
//* Description  :	Return the square distance between two integers vectors. Meaning, for ||u-v||^2
//* Parameters   :	vect1 - the first integers vector
//* Parameters   :	vect2 - the first integers vector
//* Return Value :	result (integer)
//*********************************************************************************************************
inline int SqDistance(const int& vect1, const int& vect2) {
	return SqNorm(vect1 - vect2);
}

//*********************************************************************************************************
//* function name:	TempVec
//* Description  :	Constructor of a TempVec template. 
//* Parameters   :	vect - a vector to be copied from
//* Return Value :	None
//*********************************************************************************************************
template <class T, int size>
TempVec<T, size>::TempVec(const TempVec<T, size>& vect) {
	for (int i = 0; i < size; i++)
		coordinates_[i]=vect.coordinates_[i];
}

//*********************************************************************************************************
//* function name:	operator=
//* Description  :	= operator for the template
//* Parameters   :	vect - a vector
//* Return Value :	the assignment
//*********************************************************************************************************
template <class T, int size>
TempVec<T, size>& TempVec<T, size>::operator=(const TempVec<T, size>& vect) {
	if (this != &vect) {
		delete[] coordinates_;
		coordinates_ = new T[size];
		for (int i = 0; i < size; i++) coordinates_[i] = vect.coordinates_[i];
	}
	return (*this);
}

//*********************************************************************************************************
//* function name:	InnerProduct
//* Description  :	Return the inner product between two vectors
//* Parameters   :	vect1 - the first  vector
//* Parameters   :	vect2 - the first  vector
//* Return Value :	result (T, depends on type)
//*********************************************************************************************************
template <class T, int size>
T InnerProduct(const TempVec<T, size>& vect1, const TempVec<T, size>& vect2) {
	T result = 0;
	for (int i = 0; i < size; i++)
		result = result + InnerProduct(vect1[i], vect2[i]);
	return result;
}

//*********************************************************************************************************
//* function name:	SqNorm
//* Description  :	Return the square norm of a vector. Meaning, for ||vector||^2
//* Parameters   :	vect - the vector
//* Return Value :	result (T, depends on type)
//*********************************************************************************************************
template <class T, int size>
T SqNorm(const TempVec<T, size>& vect1) {
	return InnerProduct(vect1, vect1);
}

//*********************************************************************************************************
//* function name:	SqDistance
//* Description  :	Return the square distance between two vectors. Meaning, for ||u-v||^2
//* Parameters   :	vect1 - the first vector
//* Parameters   :	vect2 - the first vector
//* Return Value :	result (T, depends on type)
//*********************************************************************************************************
template <class T, int size>
T SqDistance(const TempVec<T, size>& vect1, const TempVec<T, size>& vect2) {
	return SqNorm(vect1 - vect2);
}

#endif
